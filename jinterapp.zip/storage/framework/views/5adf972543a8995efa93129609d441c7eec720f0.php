<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Jinter App</title>
    
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
<?php if(Auth::check() && Auth::user()->role==1): ?>
<div id="top-nav-bar" catalog="2" role="1" login="1">
    <top-nav-bar ></top-nav-bar>
</div>
<?php else: ?>
<div id="top-nav-bar" catalog="2" role="2">
    <top-nav-bar ></top-nav-bar>
</div>
<?php endif; ?>
<div id="upload">
    <upload></upload>
</div>

<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</body>
</html><?php /**PATH C:\Users\Jcardz96\Desktop\jinterapp-laravel\jinterapp\resources\views/upload.blade.php ENDPATH**/ ?>